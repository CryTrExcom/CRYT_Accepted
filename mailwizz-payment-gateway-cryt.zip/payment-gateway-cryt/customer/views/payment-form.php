<?php
defined( 'MW_PATH' ) || exit( 'No direct script access allowed' );


// create form
echo CHtml::form($model->getModeUrl(), 'post', array(
    'id'         => 'cryt-hidden-form',
    'data-order' => Yii::app()->createUrl('price_plans/order'),
));
echo CHtml::hiddenField( 'cryt_address', $model->merchantId );
echo CHtml::hiddenField( 'order_id', $customVars );
$successCRYT = $notifyUrl.'?order_id='.$customVars.'&custom='.$order->customer->email.'';
echo CHtml::hiddenField( 'success_url', $successCRYT );
echo CHtml::hiddenField( 'cancel_url', $cancelUrl );
echo CHtml::hiddenField( 'notify_url', $notifyUrl );

echo CHtml::hiddenField( 'custom', $order->customer->email);
echo CHtml::hiddenField( 'amount_usd', round( $order->total, 2 ) );
echo CHtml::hiddenField('currency', $order->currency->code);
echo CHtml::hiddenField( 'item_name', Yii::t( 'price_plans', 'Price plan' ).': '. $order->plan->name );
echo CHtml::hiddenField( 'website', 'https://mailing.crytrex.com' );

?>
    <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
        CRYT Blockchain - cryt.org <br /><br />
        Pay using CRYT<br />
<img src="https://pay.cryt.org/buttons/cryt-pay.png" alt="CRYT Pay" /><br />
        <?php echo Yii::t( 'ext_payment_gateway_cryt', 'You will be redirected to pay securely via CRYT Pay' );?>
    </p>
    <p><button class="btn btn-success pull-right"><i class="fa fa-credit-card"></i> <?php echo Yii::t( 'price_plans', 'Submit payment' )?></button></p>

<?php echo CHtml::endForm(); ?>