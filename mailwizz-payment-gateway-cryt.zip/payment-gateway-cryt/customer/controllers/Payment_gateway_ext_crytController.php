<?php defined('MW_PATH') || exit('No direct script access allowed');

class Payment_gateway_ext_crytController extends Controller
{
    // the extension instance
    public $extension;
   
    /**
     * Process the IPN
     */
    public function actionIpn()
    {   
        $postData = Yii::app()->params['GET'];
		
$c = curl_init();
curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($c, CURLOPT_HTTPHEADER, array('Accept: application/json', 'Content-Type: application/json'));
curl_setopt($c, CURLOPT_URL, 'https://pay.cryt.org/order_details_ipn.php?order_id='.$postData->itemAt('order_id').'&custom='.$postData->itemAt('custom').'');
$data = curl_exec($c);
curl_close($c);
$obj = json_decode($data);
$status = print_r($obj->{'status'}, true);
$website = print_r($obj->{'website'}, true);
$cancel_url = print_r($obj->{'cancel_url'}, true);

        if (!$postData->itemAt('custom')) {
		Yii::app()->request->redirect($cancel_url);
            Yii::app()->end();
        }

        $transaction = PricePlanOrderTransaction::model()->findByAttributes(array(
            'payment_gateway_transaction_id' => $postData->itemAt('custom'),
            'status'                         => PricePlanOrderTransaction::STATUS_PENDING_RETRY,
        ));
        
        if (empty($transaction)) {
		    Yii::app()->request->redirect($cancel_url);
            Yii::app()->end();
        }

        $newTransaction = clone $transaction;
        $newTransaction->transaction_id                 = null;
        $newTransaction->transaction_uid                = null;
        $newTransaction->isNewRecord                    = true;
        $newTransaction->date_added                     = new CDbExpression('NOW()');
        $newTransaction->status                         = PricePlanOrderTransaction::STATUS_FAILED;
        $newTransaction->payment_gateway_response       = print_r($postData->toArray(), true);
        $newTransaction->payment_gateway_transaction_id = $postData->itemAt('custom');
        
        $model = $this->extension->getExtModel();
 
        $order     = $transaction->order;
        
             
        if ($status == '0') {
            $newTransaction->status = PricePlanOrderTransaction::STATUS_PENDING_RETRY;
            $newTransaction->save(false);
			Yii::app()->request->redirect($cancel_url);
            Yii::app()->end();
        }
        
        $order->status = PricePlanOrder::STATUS_COMPLETE;
        $order->save(false);
        
        $transaction->status = PricePlanOrderTransaction::STATUS_SUCCESS;
        $transaction->save(false);
        
        $newTransaction->status = PricePlanOrderTransaction::STATUS_SUCCESS;
        $newTransaction->save(false);
		Yii::app()->request->redirect($cancel_url);
        Yii::app()->end();

		
    }
}