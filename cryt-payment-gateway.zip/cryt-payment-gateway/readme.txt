=== CRYT Blockchain Payment Gateway for WooCommerce ===
Contributors: CRYT.org, Jacky, CRYT PayRequires at least: 3.7.0Tested up to: WordPress 5.4.1Stable tag: 1.0.0License: GPLv2 or laterLicense URI: http://www.gnu.org/licenses/gpl-2.0.htmlTags: cryt, cryt blockchain, cryt pay, bitcoin, litecoin, altcoins, altcoin, dogecoin, feathercoin, netcoin, peercoin, blackcoin, darkcoin, ripple, ethereum, ether, woocommerceThis plugin implements a payment gateway for WooCommerce to let buyers pay securely with CRYT via CRYT-Pay Gateway.
== Description ==This plugin implements a payment gateway for WooCommerce to let buyers pay securely with CRYT via CRYT-Pay Gateway.

== Installation ==1. Upload the `cryt-payment-gateway` directory to the `/wp-content/plugins/` directory, or upload in the Plugin install on WP admin panel.
1. Activate the plugin through the 'Plugins' menu in WordPress.
1. In the WooCommerce Settings page go to the Payment Gateways tab, then click CRYT Blockchain.
1. Check "CRYT Blockchain" and enter your CRYT Wallet Address CRYT-........
1. Click "Save changes" and the gateway will be active.

== Changelog ==
= 1.0.0 =
* Initial release.For more info about CRYT Blockchain, go to Official website: https://cryt.org
#### 3rd Party External Service ####This plugin uses the CRYT-Pay payment system, which is part of the CRYT Blockchain (https://cryt.org), the orders that will be paid through this CRYT Blockchain plugin, will be routed for payment on the secure server of the CRYT application- Pay (https://pay.cryt.org) where you can make the payment in CRYT quickly and safely and then be redirected to the ecommerce order summary.Security is important to us and the secure and official domains of the service are https://cryt.org https://pay.cryt.orgPrivacy Policy: https://cryt.org/privacy-and-cookies-policy.htmlTerms of Service: https://cryt.org/terms-and-conditions.htmlTerms of Use: https://cryt.org/terms-of-use.html